package com.janu.java8streams.service;

import java.util.List;

import com.janu.java8streams.model.Employee;



public interface EmployeeService {
	
	public List<Employee> getAllEmployee();

}
