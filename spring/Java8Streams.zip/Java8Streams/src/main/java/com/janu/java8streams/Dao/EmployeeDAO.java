package com.janu.java8streams.Dao;

import java.util.List;

import com.janu.java8streams.model.Employee;


public interface EmployeeDAO {
	public List<Employee> getAllEmployee();

}
